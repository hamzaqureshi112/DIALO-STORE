lfrom __future__ import annotations

import os
import secrets
import uuid
from pathlib import Path
from typing import Dict, Tuple
from urllib.parse import quote_plus

from flask import (
    Flask,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from database.models import (
    db,
    Order,
    OrderItem,
    Product,
    ProductImage,
    ShippingAddress,
    SliderItem,
    seed_sample_products,
)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def create_app():
    """
    Application factory that wires up extensions, templates, and routes.
    """
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", secrets.token_hex(16))
    
    # MySQL Database Configuration
    db_host = os.environ.get("DB_HOST", "localhost")
    db_port = os.environ.get("DB_PORT", "3306")
    db_user = os.environ.get("DB_USER", "root")
    db_password = os.environ.get("DB_PASSWORD", "")
    db_name = os.environ.get("DB_NAME", "dialo-store")
    
    # Build MySQL connection string
    # Use pymysql as the driver (works with SQLAlchemy)
    # URL-encode password to handle special characters
    encoded_password = quote_plus(db_password) if db_password else ""
    database_url = os.environ.get(
        "DATABASE_URL",
        f"mysql+pymysql://{db_user}:{encoded_password}@{db_host}:{db_port}/{db_name}?charset=utf8mb4"
    )
    
    app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_pre_ping": True,  # Verify connections before using
        "pool_recycle": 300,    # Recycle connections after 5 minutes
    }
    app.config["UPLOAD_FOLDER"] = Path(app.root_path) / "static" / "uploads" / "products"
    app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024  # 8 MB uploads

    Path(app.config["UPLOAD_FOLDER"]).mkdir(parents=True, exist_ok=True)

    db.init_app(app)

    with app.app_context():
        db.create_all()
        seed_sample_products()

    register_routes(app)
    return app


def allowed_file(file: FileStorage) -> bool:
    return "." in file.filename and file.filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def save_image(file: FileStorage) -> str:
    """
    Persist an uploaded image and return the relative path for templates.
    """
    if not file or file.filename == "":
        return ""
    if not allowed_file(file):
        raise ValueError("Unsupported file type. Please upload PNG, JPG, or WEBP images.")

    filename = secure_filename(file.filename)
    unique_name = f"{uuid.uuid4().hex}_{filename}"
    destination = Path(current_app.config["UPLOAD_FOLDER"]) / unique_name
    file.save(destination)
    rel_path = destination.relative_to(Path(current_app.root_path) / "static")
    return f"/static/{rel_path.as_posix()}"


def get_cart() -> Dict[str, int]:
    """
    Retrieve the session cart (product_id -> qty).
    """
    return session.setdefault("cart", {})


def get_cart_summary() -> Tuple[list, float]:
    cart = get_cart()
    items = []
    subtotal = 0.0

    for product_id, qty in cart.items():
        product = Product.query.get(int(product_id))
        if not product:
            continue
        line_total = float(product.price) * qty
        subtotal += line_total
        items.append({"product": product, "quantity": qty, "line_total": line_total})

    return items, subtotal


def require_admin():
    if not session.get("is_admin"):
        flash("Please sign in to continue.", "warning")
        return redirect(url_for("admin_login"))
    return None


def register_routes(app: Flask) -> None:
    """
    Register all page, API, cart, and admin routes.
    """

    # --- Storefront routes -------------------------------------------------
    @app.context_processor
    def inject_globals():
        items, subtotal = get_cart_summary()
        return {
            "nav_cart_count": sum(item["quantity"] for item in items),
            "nav_cart_subtotal": subtotal,
        }

    @app.route("/")
    def home():
        featured = Product.query.filter_by(featured=True).order_by(Product.created_at.desc()).limit(4)
        latest = Product.query.order_by(Product.created_at.desc()).limit(6)
        slider_items = SliderItem.query.filter_by(active=True).order_by(SliderItem.display_order).all()
        return render_template("home.html", featured=featured, latest=latest, slider_items=slider_items)

    @app.route("/craft")
    def craft():
        return render_template("craft.html")

    @app.route("/stories")
    def stories():
        return render_template("stories.html")

    @app.route("/watches")
    def catalog():
        query = Product.query
        brand = request.args.get("brand")
        strap = request.args.get("strap")
        movement = request.args.get("movement")
        sort = request.args.get("sort", "newest")

        if brand:
            query = query.filter(Product.brand.ilike(f"%{brand}%"))
        if strap:
            query = query.filter(Product.strap.ilike(f"%{strap}%"))
        if movement:
            query = query.filter(Product.movement.ilike(f"%{movement}%"))

        if sort == "price_low":
            query = query.order_by(Product.price.asc())
        elif sort == "price_high":
            query = query.order_by(Product.price.desc())
        else:
            query = query.order_by(Product.created_at.desc())

        products = query.all()
        brands = sorted({p.brand for p in Product.query.all() if p.brand})
        return render_template(
            "catalog.html",
            products=products,
            brands=brands,
            current_filters={"brand": brand, "strap": strap, "movement": movement, "sort": sort},
        )

    @app.route("/watch/<slug>")
    def product_detail(slug: str):
        product = Product.query.filter_by(slug=slug).first_or_404()
        related = (
            Product.query.filter(Product.id != product.id, Product.brand == product.brand)
            .order_by(Product.created_at.desc())
            .limit(3)
        )
        return render_template("product_detail.html", product=product, related=related)

    # --- Cart + checkout ---------------------------------------------------
    @app.route("/cart")
    def cart():
        items, subtotal = get_cart_summary()
        shipping = 0 if subtotal >= 2000 else 25 if subtotal else 0
        total = subtotal + shipping
        return render_template(
            "cart.html",
            items=items,
            subtotal=subtotal,
            shipping=shipping,
            total=total,
        )

    @app.post("/cart/add/<int:product_id>")
    def add_to_cart(product_id: int):
        product = Product.query.get_or_404(product_id)
        cart = get_cart()
        cart[str(product.id)] = cart.get(str(product.id), 0) + int(request.form.get("quantity", 1))
        session.modified = True
        flash(f"{product.name} added to your cart.", "success")
        return redirect(request.referrer or url_for("cart"))

    @app.post("/cart/update/<int:product_id>")
    def update_cart_item(product_id: int):
        cart = get_cart()
        qty = max(0, int(request.form.get("quantity", 1)))
        key = str(product_id)
        if qty <= 0:
            cart.pop(key, None)
        else:
            cart[key] = qty
        session.modified = True
        flash("Cart updated.", "info")
        return redirect(url_for("cart"))

    @app.post("/cart/remove/<int:product_id>")
    def remove_cart_item(product_id: int):
        cart = get_cart()
        cart.pop(str(product_id), None)
        session.modified = True
        flash("Item removed from cart.", "info")
        return redirect(url_for("cart"))

    @app.route("/checkout", methods=["GET", "POST"])
    def checkout():
        items, subtotal = get_cart_summary()
        if not items:
            flash("Add a watch to your cart to checkout.", "warning")
            return redirect(url_for("catalog"))

        shipping_cost = 0 if subtotal >= 2000 else 25
        total = subtotal + shipping_cost

        if request.method == "POST":
            form = request.form
            required_fields = ["full_name", "email", "phone", "address", "city", "country", "postal_code"]
            missing = [field for field in required_fields if not form.get(field)]
            if missing:
                flash("Please fill out every field in the shipping form.", "danger")
                return redirect(url_for("checkout"))

            shipping = ShippingAddress(
                full_name=form["full_name"],
                email=form["email"],
                phone=form["phone"],
                address_line=form["address"],
                city=form["city"],
                country=form["country"],
                postal_code=form["postal_code"],
                notes=form.get("notes"),
            )
            db.session.add(shipping)

            order = Order(
                reference=f"DIALO-{uuid.uuid4().hex[:8].upper()}",
                subtotal=subtotal,
                shipping_cost=shipping_cost,
                total=total,
                status="processing",
                shipping_address=shipping,
            )
            db.session.add(order)
            db.session.flush()

            for item in items:
                db.session.add(
                    OrderItem(
                        order_id=order.id,
                        product_id=item["product"].id,
                        quantity=item["quantity"],
                        unit_price=item["product"].price,
                    )
                )

            db.session.commit()
            session["cart"] = {}
            flash("Thank you for your order! We are preparing your shipment.", "success")
            return redirect(url_for("order_confirmation", reference=order.reference))

        return render_template(
            "checkout.html",
            items=items,
            subtotal=subtotal,
            shipping=shipping_cost,
            total=total,
        )

    @app.route("/order/<reference>")
    def order_confirmation(reference: str):
        order = Order.query.filter_by(reference=reference).first_or_404()
        return render_template("order_confirmation.html", order=order)

    # --- Admin -------------------------------------------------------------
    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        if request.method == "POST":
            username = request.form.get("username")
            password = request.form.get("password")
            if username == os.environ.get("ADMIN_USERNAME", "admin") and password == os.environ.get(
                "ADMIN_PASSWORD", "admin"
            ):
                session["is_admin"] = True
                flash("Welcome back, admin.", "success")
                return redirect(url_for("admin_dashboard"))
            flash("Invalid credentials.", "danger")
        return render_template("admin_login.html")

    @app.get("/admin/logout")
    def admin_logout():
        session.pop("is_admin", None)
        flash("Signed out.", "info")
        return redirect(url_for("admin_login"))

    @app.route("/admin")
    def admin_dashboard():
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response

        total_products = Product.query.count()
        total_orders = Order.query.count()
        revenue = db.session.query(db.func.sum(Order.total)).scalar() or 0
        latest_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
        return render_template(
            "admin_dashboard.html",
            total_products=total_products,
            total_orders=total_orders,
            revenue=revenue,
            latest_orders=latest_orders,
        )

    @app.route("/admin/products")
    def admin_products():
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response

        products = Product.query.order_by(Product.created_at.desc()).all()
        return render_template("admin_products.html", products=products)

    @app.route("/admin/products/new", methods=["GET", "POST"])
    def admin_product_new():
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response

        if request.method == "POST":
            try:
                return handle_product_form(request)
            except ValueError as exc:
                flash(str(exc), "danger")
        return render_template("admin_product_form.html", product=None)

    @app.route("/admin/products/<int:product_id>/edit", methods=["GET", "POST"])
    def admin_product_edit(product_id: int):
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response

        product = Product.query.get_or_404(product_id)
        if request.method == "POST":
            try:
                return handle_product_form(request, product)
            except ValueError as exc:
                flash(str(exc), "danger")
        return render_template("admin_product_form.html", product=product)

    @app.post("/admin/products/<int:product_id>/delete")
    def admin_product_delete(product_id: int):
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response

        product = Product.query.get_or_404(product_id)
        db.session.delete(product)
        db.session.commit()
        flash("Product removed.", "info")
        return redirect(url_for("admin_products"))

    @app.route("/admin/slider")
    def admin_slider():
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response
        slider_items = SliderItem.query.order_by(SliderItem.display_order).all()
        return render_template("admin_slider.html", slider_items=slider_items)

    @app.route("/admin/slider/new", methods=["GET", "POST"])
    def admin_slider_new():
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response

        if request.method == "POST":
            title = request.form.get("title", "").strip()
            description = request.form.get("description", "").strip()
            price = request.form.get("price", "").strip()
            display_order = int(request.form.get("display_order", 0) or 0)
            active = request.form.get("active") == "on"

            if not title or not description or not price:
                flash("Title, description, and price are required.", "danger")
                return redirect(url_for("admin_slider_new"))

            image_file = request.files.get("image")
            image_url = ""
            if image_file and image_file.filename:
                image_url = save_image(image_file)

            slider_item = SliderItem(
                title=title,
                description=description,
                price=price,
                image_url=image_url,
                display_order=display_order,
                active=active,
            )
            db.session.add(slider_item)
            db.session.commit()
            flash("Slider item added.", "success")
            return redirect(url_for("admin_slider"))

        return render_template("admin_slider_form.html")

    @app.route("/admin/slider/<int:item_id>/edit", methods=["GET", "POST"])
    def admin_slider_edit(item_id: int):
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response

        slider_item = SliderItem.query.get_or_404(item_id)

        if request.method == "POST":
            slider_item.title = request.form.get("title", "").strip()
            slider_item.description = request.form.get("description", "").strip()
            slider_item.price = request.form.get("price", "").strip()
            slider_item.display_order = int(request.form.get("display_order", 0) or 0)
            slider_item.active = request.form.get("active") == "on"

            image_file = request.files.get("image")
            if image_file and image_file.filename:
                slider_item.image_url = save_image(image_file)

            db.session.commit()
            flash("Slider item updated.", "success")
            return redirect(url_for("admin_slider"))

        return render_template("admin_slider_form.html", item=slider_item)

    @app.route("/admin/slider/<int:item_id>/delete", methods=["POST"])
    def admin_slider_delete(item_id: int):
        redirect_response = require_admin()
        if redirect_response:
            return redirect_response

        slider_item = SliderItem.query.get_or_404(item_id)
        db.session.delete(slider_item)
        db.session.commit()
        flash("Slider item deleted.", "success")
        return redirect(url_for("admin_slider"))


def handle_product_form(req, product: Product | None = None):
    """
    Shared helper for admin create/update forms.
    """
    name = req.form.get("name", "").strip()
    price = req.form.get("price", "").strip()
    description = req.form.get("description", "").strip()
    brand = req.form.get("brand", "").strip()
    movement = req.form.get("movement", "").strip()
    strap = req.form.get("strap", "").strip()
    inventory = req.form.get("inventory", "").strip() or "0"
    featured = bool(req.form.get("featured"))

    if not name or not price:
        raise ValueError("Name and price are required.")

    price_value = float(price)
    inventory_value = int(inventory)

    slug = req.form.get("slug") or "-".join(name.lower().split())

    hero_file = req.files.get("hero_image")
    gallery_files = req.files.getlist("gallery")

    if product is None:
        product = Product(name=name, slug=slug)
        db.session.add(product)
    else:
        product.slug = slug

    product.name = name
    product.price = price_value
    product.description = description
    product.brand = brand or "DIALO"
    product.movement = movement or "Automatic"
    product.strap = strap or "Leather"
    product.inventory = inventory_value
    product.featured = featured

    if hero_file and hero_file.filename:
        product.hero_image = save_image(hero_file)

    if gallery_files:
        for file in gallery_files:
            if not file or not file.filename:
                continue
            image_path = save_image(file)
            db.session.add(ProductImage(product=product, image_url=image_path))

    db.session.commit()
    flash("Product saved.", "success")
    return redirect(url_for("admin_products"))


app = create_app()


if __name__ == "__main__":
    app.run(debug=True)

