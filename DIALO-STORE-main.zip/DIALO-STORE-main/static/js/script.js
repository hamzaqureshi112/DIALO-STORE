document.addEventListener("DOMContentLoaded", () => {
  enableSmoothScroll();
  bindFilePreview();
  initWatchSlider();
});

function enableSmoothScroll() {
  document.querySelectorAll("a[href^='#']").forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
      const target = document.querySelector(anchor.getAttribute("href"));
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });
}

function bindFilePreview() {
  const heroInput = document.querySelector("input[name='hero_image']");
  if (!heroInput) return;

  heroInput.addEventListener("change", (event) => {
    const [file] = event.target.files;
    if (!file) return;
    const preview = heroInput.parentElement.querySelector(".preview");
    if (!preview) return;
    preview.src = URL.createObjectURL(file);
  });
}

function initWatchSlider() {
  const slider = document.querySelector(".watch-slider");
  if (!slider) return;

  const slides = slider.querySelectorAll(".slider-slide");
  const dots = slider.querySelectorAll(".dot");
  const prevBtn = slider.querySelector(".slider-btn.prev");
  const nextBtn = slider.querySelector(".slider-btn.next");
  
  if (slides.length === 0) return;
  
  // If only one slide, disable navigation
  if (slides.length === 1) {
    if (prevBtn) prevBtn.style.opacity = "0.3";
    if (nextBtn) nextBtn.style.opacity = "0.3";
    return;
  }

  let currentSlide = 0;
  let autoplayInterval;

  function showSlide(index) {
    // Remove active class from all slides and dots
    slides.forEach((slide, i) => {
      slide.classList.remove("active", "prev");
      if (i < index) {
        slide.classList.add("prev");
      }
    });
    dots.forEach((dot) => dot.classList.remove("active"));

    // Add active class to current slide and dot
    slides[index].classList.add("active");
    if (dots[index]) {
      dots[index].classList.add("active");
    }

    currentSlide = index;
  }

  function nextSlide() {
    const next = (currentSlide + 1) % slides.length;
    showSlide(next);
  }

  function prevSlide() {
    const prev = (currentSlide - 1 + slides.length) % slides.length;
    showSlide(prev);
  }

  function startAutoplay() {
    autoplayInterval = setInterval(nextSlide, 5000);
  }

  function stopAutoplay() {
    if (autoplayInterval) {
      clearInterval(autoplayInterval);
    }
  }

  // Button event listeners
  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      nextSlide();
      stopAutoplay();
      startAutoplay();
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener("click", () => {
      prevSlide();
      stopAutoplay();
      startAutoplay();
    });
  }

  // Dot event listeners
  dots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
      showSlide(index);
      stopAutoplay();
      startAutoplay();
    });
  });

  // Pause autoplay on hover
  slider.addEventListener("mouseenter", stopAutoplay);
  slider.addEventListener("mouseleave", startAutoplay);

  // Touch/swipe support for mobile
  let touchStartX = 0;
  let touchEndX = 0;

  slider.addEventListener("touchstart", (e) => {
    touchStartX = e.changedTouches[0].screenX;
    stopAutoplay();
  });

  slider.addEventListener("touchend", (e) => {
    touchEndX = e.changedTouches[0].screenX;
    handleSwipe();
    startAutoplay();
  });

  function handleSwipe() {
    const swipeThreshold = 50;
    const diff = touchStartX - touchEndX;

    if (Math.abs(diff) > swipeThreshold) {
      if (diff > 0) {
        nextSlide();
      } else {
        prevSlide();
      }
    }
  }

  // Keyboard navigation
  document.addEventListener("keydown", (e) => {
    if (!slider.matches(":hover") && !document.querySelector(".watch-slider-section").matches(":hover")) {
      return;
    }
    if (e.key === "ArrowLeft") {
      prevSlide();
      stopAutoplay();
      startAutoplay();
    } else if (e.key === "ArrowRight") {
      nextSlide();
      stopAutoplay();
      startAutoplay();
    }
  });

  // Initialize
  showSlide(0);
  startAutoplay();
}
