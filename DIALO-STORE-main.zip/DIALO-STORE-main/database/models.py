"""
SQLAlchemy models and seed helpers for the DIALO e-commerce experience.
"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Iterable

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class TimestampMixin:
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Product(db.Model, TimestampMixin):
    __tablename__ = "products"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    slug = db.Column(db.String(180), unique=True, nullable=False)
    brand = db.Column(db.String(100), default="DIALO")
    strap = db.Column(db.String(100), default="Leather")
    movement = db.Column(db.String(100), default="Automatic")
    price = db.Column(db.Numeric(10, 2), nullable=False)
    description = db.Column(db.Text)
    hero_image = db.Column(db.String(255))
    featured = db.Column(db.Boolean, default=False)
    inventory = db.Column(db.Integer, default=0)

    images = db.relationship("ProductImage", backref="product", cascade="all, delete-orphan")
    order_items = db.relationship("OrderItem", backref="product")

    def first_image(self) -> str:
        if self.hero_image:
            return self.hero_image
        if self.images:
            return self.images[0].image_url
        return "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=800&q=80"


class ProductImage(db.Model):
    __tablename__ = "product_images"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    image_url = db.Column(db.String(255), nullable=False)


class ShippingAddress(db.Model, TimestampMixin):
    __tablename__ = "shipping_addresses"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(160), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    phone = db.Column(db.String(50), nullable=False)
    address_line = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(120), nullable=False)
    country = db.Column(db.String(100), nullable=False)
    postal_code = db.Column(db.String(20), nullable=False)
    notes = db.Column(db.Text)

    order = db.relationship("Order", back_populates="shipping_address", uselist=False)


class Order(db.Model, TimestampMixin):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    reference = db.Column(db.String(32), unique=True, nullable=False)
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    shipping_cost = db.Column(db.Numeric(10, 2), nullable=False)
    total = db.Column(db.Numeric(10, 2), nullable=False)
    status = db.Column(db.String(30), default="processing")
    shipping_address_id = db.Column(db.Integer, db.ForeignKey("shipping_addresses.id"))

    shipping_address = db.relationship("ShippingAddress", back_populates="order")
    items = db.relationship("OrderItem", backref="order", cascade="all, delete-orphan")


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Numeric(10, 2), nullable=False)


class SliderItem(db.Model, TimestampMixin):
    __tablename__ = "slider_items"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.String(255), nullable=False)
    price = db.Column(db.String(50), nullable=False)
    image_url = db.Column(db.String(255))
    display_order = db.Column(db.Integer, default=0)
    active = db.Column(db.Boolean, default=True)


def seed_sample_products() -> None:
    """
    Populate the database with a curated set of sample watches when empty.
    """
    if Product.query.count():
        return

    sample_data: Iterable[dict] = [
        {
            "name": "DIALO Orion Eclipse",
            "slug": "dialo-orion-eclipse",
            "brand": "DIALO Atelier",
            "strap": "Midnight Leather",
            "movement": "Automatic",
            "price": Decimal("2890.00"),
            "inventory": 12,
            "featured": True,
            "hero_image": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80",
            "description": "A moonphase complication meets mirror-polished indices inspired by lunar light.",
        },
        {
            "name": "DIALO Meridian GMT",
            "slug": "dialo-meridian-gmt",
            "brand": "DIALO Atelier",
            "strap": "Steel Bracelet",
            "movement": "Automatic GMT",
            "price": Decimal("3150.00"),
            "inventory": 9,
            "featured": True,
            "hero_image": "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=900&q=80",
            "description": "Track two time zones with a bevel-cut sapphire bezel and luminous ceramic dial.",
        },
        {
            "name": "DIALO Luminor Classic",
            "slug": "dialo-luminor-classic",
            "brand": "DIALO Heritage",
            "strap": "Chestnut Leather",
            "movement": "Hand-wound",
            "price": Decimal("1850.00"),
            "inventory": 15,
            "featured": False,
            "hero_image": "https://images.unsplash.com/photo-1518444028784-9cfa46f1b6ba?auto=format&fit=crop&w=900&q=80",
            "description": "Our archival cushion case reimagined with a warm fumé dial and blued hands.",
        },
        {
            "name": "DIALO Axiom Carbon",
            "slug": "dialo-axiom-carbon",
            "brand": "DIALO Lab",
            "strap": "Forged Carbon",
            "movement": "Chronograph",
            "price": Decimal("4290.00"),
            "inventory": 6,
            "featured": True,
            "hero_image": "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=900&q=80",
            "description": "Ultra-light forged carbon case with vertical-clutch chronograph calibre.",
        },
        {
            "name": "DIALO Solstice 38",
            "slug": "dialo-solstice-38",
            "brand": "DIALO Atelier",
            "strap": "Silk Calfskin",
            "movement": "Automatic",
            "price": Decimal("1620.00"),
            "inventory": 22,
            "featured": False,
            "hero_image": "https://images.unsplash.com/photo-1508962914676-134849a727f0?auto=format&fit=crop&w=900&q=80",
            "description": "A 38mm silhouette with champagne dial, perfect proportions, and haute-couture polish.",
        },
    ]

    for entry in sample_data:
        db.session.add(Product(**entry))

    # Seed sample slider items
    if SliderItem.query.count() == 0:
        slider_data = [
            {
                "title": "Orion Eclipse",
                "description": "Moonphase complication with hand-guilloché dial",
                "price": "$12,500",
                "image_url": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80",
                "display_order": 0,
                "active": True,
            },
            {
                "title": "Axiom Carbon",
                "description": "Chronograph with carbon fiber case and titanium bezel",
                "price": "$15,800",
                "image_url": "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=900&q=80",
                "display_order": 1,
                "active": True,
            },
            {
                "title": "Meridian GMT",
                "description": "Dual timezone with meteorite dial and sapphire crystal",
                "price": "$18,200",
                "image_url": "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=900&q=80",
                "display_order": 2,
                "active": True,
            },
            {
                "title": "Nova Chronograph",
                "description": "Racing-inspired design with ceramic bezel insert",
                "price": "$14,900",
                "image_url": "https://images.unsplash.com/photo-1518444028784-9cfa46f1b6ba?auto=format&fit=crop&w=900&q=80",
                "display_order": 3,
                "active": True,
            },
        ]
        for item in slider_data:
            db.session.add(SliderItem(**item))

    db.session.commit()

