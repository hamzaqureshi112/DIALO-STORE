"""
Database configuration module.
Creates and returns a MySQL connection using mysql-connector-python.
"""
import os
from typing import Optional

import mysql.connector
from mysql.connector import Error, MySQLConnection


DB_CONFIG = {
    "host": os.environ.get("DB_HOST", "localhost"),
    "port": int(os.environ.get("DB_PORT", "3306")),
    "user": os.environ.get("DB_USER", "root"),
    "password": os.environ.get("DB_PASSWORD", "password"),
    "database": os.environ.get("DB_NAME", "college_store"),
}


def get_db_connection() -> Optional[MySQLConnection]:
    """
    Create and return a MySQL connection.
    Returns None if connection cannot be established.
    """
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except Error as exc:
        print(f"[DB] Connection error: {exc}")
        return None

