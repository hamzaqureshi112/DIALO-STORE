class Complex:
    def __init__(self, real, imag):
        self.real = real
        self.imag = imag

    def multiply(self, other):
        r = self.real * other.real - self.imag * other.imag
        i = self.real * other.imag + self.imag * other.real
        return Complex(r, i)

    def divide(self, other):
        d = other.real**2 + other.imag**2
        r = (self.real * other.real + self.imag * other.imag) / d
        i = (self.imag * other.real - self.real * other.imag) / d
        return Complex(r, i)

    def show(self):
        print(f"{self.real} + {self.imag}i")


# Input
a = float(input("Real part of first complex number: "))
b = float(input("Imaginary part of first complex number: "))
c = float(input("Real part of second complex number: "))
d = float(input("Imaginary part of second complex number: "))

x = Complex(a, b)
y = Complex(c, d)

# Results
m = x.multiply(y)
d = x.divide(y)

print("\nMultiplication:")
m.show()

print("Division:")
d.show()
